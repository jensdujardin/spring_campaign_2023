
## -----------------------------------------------------------
## Get data, 3 columns on which to fit a model
## -----------------------------------------------------------

GetPEdata <- function(data, which = NULL, id = NULL, PAR = NULL, minPAR = 0.1, 
  environment = NULL) {
  P <- ifelse(is.null(PAR), "PAR", PAR)
  if (! P %in% colnames(data))
    stop("column with PAR data, ", P, " not found - supply name of column with PAR data" )
  if (is.null(PAR))
    PAR <- pmax(minPAR, data$PAR)
  else if (is.character(PAR))
    PAR <- pmax(minPAR, data[,PAR])
  
    
  T <- LAT <- LON <- NA
  if (is.null(id)) {
    ii <- c(0, which(PAR[-1]/PAR[-nrow(data)] < 0.1), nrow(data))
    id <- as.vector(unlist(sapply(2:length(ii), FUN = function(i) rep(i-1, ii[i] - ii[i-1]))))
    if (! is.null(data$Date) & ! is.null(data$Time)) {
      # this is all too complex
      TT <- as.POSIXlt(paste(data$Date, data$Time), format = "%d/%m/%Y %T")
      T1 <- TT[ii[-length(ii)]+1]
      T2 <- c(T1[-1], TT[nrow(data)])
      
      T <- lapply(2:(length(ii)), FUN = function(i) mean(TT[(ii[i-1]+1) : ii[i]]))
      Tdiff <- (as.POSIXlt(T2) - as.POSIXlt(T1))
      T <- as.vector(t(as.data.frame(T)))
    } else   if (! is.null(data$Date)) {
      # this is all too complex
      TT <- as.POSIXlt(data$Date, format = "%d/%m/%Y")
      T1 <- TT[ii[-length(ii)]+1]
      T2 <- c(T1[-1], TT[nrow(data)])

      T <- lapply(2:(length(ii)), FUN = function(i) mean(TT[(ii[i-1]+1) : ii[i]]))
      Tdiff <- (as.POSIXlt(T2) - as.POSIXlt(T1))
      T <- as.vector(t(as.data.frame(T)))
    } else {
      T1 <- T2 <- T <- Tdiff <- NA
    }

    envir <- data.frame(ini_time = T1, end_time = T2, mean_time = T, duration_min = Tdiff)
    cn <- names(data)
    for (e in environment) {
      if (e %in% cn) 
        envir[,e] <- sapply(2:(length(ii)-1), FUN = function(i) mean(data[(ii[i-1]+1) : ii[i], e]))
      else
        warning("environment variable ", e, " not found")  
    }
  }
  if (is.null(which))
    Dat <- data.frame(id = id, PAR = PAR, data)
  
  else  {
    Dat <- data.frame(id = id, PAR = PAR, data[, which])
    Dat <- Dat[! is.na(Dat[,3]), ]
    names(Dat)[-(1:2)] <- which
  }
   
  attr (Dat, "environment") <- envir
  return(Dat)
}  

PEcoef <- function(object) {
  if ("FRRF" %in% class(object)) return (summary(object))
  CM <- coef(object)
  SM <- summary(object)
  StdErr <- matrix (nrow = length(SM$sigma), data = SM$par$Std..Error, byrow = TRUE)
  
  colnames(StdErr) <- paste("STD", colnames(CM), sep = "")
  X <- cbind(attributes(object)$environment, CM)
  if (object$model %in% c("Webb", "JP")) {
    X$ps <- X$ek*X$alpha
    StdErr$STDps <- sqrt(StdErr$STDek^2 + StdErr$STDalpha^2)
  }  
  X <- cbind(X, StdErr)
  X$sig <- SM$sigma
  X$rsq <- SM$rsq  
  X
}

predict.multFRRF <- function (object, PAR, ...) {
  y <- NULL
  for (i in 1:nrow(object$par)) {
    FIT <- object
    class(FIT) <- c("FRRF", "modFit")
    FIT$par <- object$par[i,]
    y <- cbind(y, predict(FIT, PAR, ...))
  } 
  y   
}

summary.multFRRF <- function (object, ...) {
  n <- ncol(object$par)
  m <- nrow(object$par)
  ids <- names(object$ids)
  PP <- NULL
  sigma <- vector(length = m)
  df <- vector(length = m)
  residualVariance <- vector(length = m)
  modVariance <- vector(length = m)
  niter <- vector(length = m)
  rsq <- r.squared(object)
  for (i in 1:nrow(object$par)) {
    FIT <- attributes(object)$modFit[[i]]
    if (! is.na(FIT$ssr)) {
      SM <- summary(FIT)
      PP <- rbind(PP, data.frame(ids = rep(ids[i], n), SM$par))
      sigma[i] <- SM$sigma
      df[i] <- SM$df[2]
      residualVariance[i] <- SM$residualVariance
      modVariance[i] <- SM$modVariance
      niter[i] <- SM$niter
    } else {
      SMp <- matrix(nrow = n, ncol = 4, data = NA)
      rownames(SMp) <- colnames(object$par)
      colnames(SMp) <- c("Estimate", "Std. Error", "t value", "Pr(>|t|)") 
      PP <- rbind(PP, data.frame(ids = rep(ids[i], n), SMp))
    }    
  } 
  ans <- list(residuals = object$residuals, residualVariance = residualVariance, 
        sigma = sigma, modVariance = modVariance, df = df, rsq = rsq, 
        niter = niter, par = PP, ids = object$ids)
  class(ans) <- "summary.multFRRF"      
  ans 
}

print.summary.multFRRF <- function (x, digits = max(3, getOption("digits") - 3), ...) 
{

    cat("\nParameters:\n")
    printCoefmat(x$par, digits = digits, ...)

    cat("\nResidual standard error and degrees of freedom:\n")
    stderrdf <- as.data.frame(rbind(sigma = x$sigma, df = x$df, rsq = x$rsq ))
    names(stderrdf) <- names(x$ids)
    printCoefmat(stderrdf, digits = digits, ...)

#    cat("\nResidual standard error:", format(signif(x$sigma, 
#        digits)))
#    cat("\nDegrees of freedom:", df, "\n")
    invisible(x)
}


PEmult <- function(model, id, PAR, response, data = NULL, 
  normalized = FALSE, pini = NULL, 
 ...) {

  if (is.character(id))
    id <- data[,id]
  if (is.character(PAR))
    PAR <- data[,PAR]
  if (is.character(response))
    response <- data[,response]
    
  iun       <- unique(id)
  n         <- length(iun)
  ssr       <- rep(NA, n)
  ms        <- rep(NA, n)
  residuals <- rep(NA, length(id))

  pars <- NULL       
  ids  <- table(id)
  mFIT <- list()
  
  for (i in 1:n){
    
    #Identify & isolate data
    pos   <- which(id == iun[i])
    myfit <- PEfit(model, PAR[pos], response[pos], normalized, pini = pini, ...) 
    pars  <- rbind(pars, myfit$par)    

    ssr[i]         <- myfit$ssr
    ms[i]          <- myfit$ms
    residuals[pos] <- myfit$residuals
    
    mFIT[[i]] <- myfit
    
  }
    
   FIT <- list(par = pars, ssr = ssr, ms = ms, residuals = residuals, ids = ids)
   FIT$model <- model
   FIT$normalized <- normalized
   class(FIT) <- c("multFRRF", "modFit")
   attr(FIT, "modFit") <- mFIT 
   if (! is.null(data))
     attr(FIT, "environment") <- attributes(data)$environment 
   return(FIT)  
}
